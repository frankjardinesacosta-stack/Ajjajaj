# GitHub Actions: compilar el proyecto iOS

1. Crea un repositorio en GitHub.
2. Descomprime este paquete y sube **todo el contenido** de `PantherIOS-External-VIP-Menu` a la raíz del repositorio. No subas el ZIP como un único archivo.
3. Confirma que `.github/workflows/build-ipa.yml` y `ThreeOneOSFive.xcodeproj` estén en la raíz del repositorio.
4. En GitHub, abre la pestaña **Actions**. El flujo también se ejecuta al hacer push o abrir un pull request hacia `main` o `master`.
5. Para ejecutarlo manualmente, entra en **Actions → Panther iOS - Build IPA → Run workflow**.
6. Cuando termine, abre la ejecución y descarga el artefacto **Panther-iOS-unsigned** en la sección **Artifacts**.

El IPA generado no está firmado. Para instalarlo en un dispositivo se necesita firmarlo con un método y certificado válidos. Este flujo no guarda certificados ni secretos de firma.
